"""
Homework 5 CNNs
CS1430 - Computer Vision
Brown University
"""

import tensorflow as tf
import keras
import keras.layers as kl

from keras.layers import \
    Conv2D, MaxPool2D, Dropout, Flatten, Dense

import hyperparameters as hp

class ConvNeXt_block(kl.Layer):
    def __init__(self, filters, scale=2, act=True):
        super(ConvNeXt_block, self).__init__()

        self.main_path = keras.Sequential([
            kl.ZeroPadding2D(padding=3),
            kl.Conv2D(filters, 7, strides=1, use_bias=False),
            kl.LayerNormalization(axis=-1, epsilon=0.001),
            kl.Conv2D(filters*scale, 1, strides=1, use_bias=True),
            kl.Activation("gelu"),
            kl.Conv2D(filters, 1, strides=1, use_bias=True)
        ])
        self.shortcut = kl.Layer()
        self.add_path = kl.Add()
        self.act = act
        if act: 
            self.act_out = kl.Activation("gelu")

    def call(self, x):
        main_head = self.main_path(x)
        shortcut_head = self.shortcut(x)
        y = self.add_path([main_head, shortcut_head])
        if self.act:
            y = self.act_out(y)
        return y
    
class DownSampleConv(kl.Layer):
    def __init__(self, filters, kernel, stride, padding):
        super(DownSampleConv, self).__init__()

        self.conv = keras.Sequential([
            kl.ZeroPadding2D(padding=padding),
            kl.Conv2D(filters, kernel, strides=stride, use_bias=False),
            kl.Activation("gelu"),
        ])

    def call(self, x):
        y = self.conv(x)
        return y

class DownSampleConvN(kl.Layer):
    def __init__(self, filters, kernel, stride, padding=0):
        super(DownSampleConvN, self).__init__()

        self.conv = keras.Sequential([
            kl.LayerNormalization(axis=-1, epsilon=0.001),
            kl.Conv2D(filters, kernel, strides=stride, use_bias=False),
        ])

    def call(self, x):
        y = self.conv(x)
        return y

class ResBlock(kl.Layer):
    def __init__(self, filters, kernel_size=3, numerical_name=False):
        super(ResBlock, self).__init__()

        self.main_path = keras.Sequential([
            kl.ZeroPadding2D(padding=1),
            kl.Conv2D(filters, kernel_size, strides=1),
            kl.Activation( "gelu"),
            kl.ZeroPadding2D(padding=1),
            kl.Conv2D(filters, kernel_size, strides=1, use_bias=False)
        ])
        self.shortcut = kl.Conv2D(filters, 1, strides=1, use_bias=False)

        self.add_path = kl.Add()
        self.act_out = kl.Activation("gelu")

    def call(self, x):
        main_head = self.main_path(x)
        shortcut_head = self.shortcut(x)
        y = self.add_path([main_head, shortcut_head])
        y = self.act_out(y)
        return y

class YourModel(tf.keras.Model):
    """ Your own neural network model. """

    def __init__(self):
        super(YourModel, self).__init__()

        # TODO: Select an optimizer for your network (see the documentation
        #       for tf.keras.optimizers)
        self.optimizer = tf.keras.optimizers.RMSprop(
            learning_rate=hp.learning_rate,
            momentum=hp.momentum)

        # TODO: Build your own convolutional neural network, using Dropout at
        #       least once. The input image will be passed through each Keras
        #       layer in self.architecture sequentially. Refer to the imports
        #       to see what Keras layers you can use to build your network.
        #       Feel free to import other layers, but the layers already
        #       imported are enough for this assignment.
        #
        #       Remember: Your network must have under 15 million parameters!
        #       You will see a model summary when you run the program that
        #       displays the total number of parameters of your network.
        #
        #       Remember: Because this is a 15-scene classification task,
        #       the output dimension of the network must be 15. That is,
        #       passing a tensor of shape [batch_size, img_size, img_size, 1]
        #       into the network will produce an output of shape
        #       [batch_size, 15].
        #
        #       Note: Keras layers such as Conv2D and Dense give you the
        #             option of defining an activation function for the layer.
        #             For example, if you wanted ReLU activation on a Conv2D
        #             layer, you'd simply pass the string 'relu' to the
        #             activation parameter when instantiating the layer.
        #             While the choice of what activation functions you use
        #             is up to you, the final layer must use the softmax
        #             activation function so that the output of your network
        #             is a probability distribution.
        #
        #       Note: Flatten is a very useful layer. You shouldn't have to
        #             explicitly reshape any tensors anywhere in your network.

        self.architecture = [
            kl.Conv2D(96, 4, strides=4),
            kl.LayerNormalization(axis=-1, epsilon=0.001),
            ConvNeXt_block(96, 4, act=False),
            ConvNeXt_block(96, 4, act=False),
            DownSampleConvN(128,2,2,0),
            ConvNeXt_block(128, 2, act=False),
            ConvNeXt_block(128, 4, act=False),
            DownSampleConvN(192,2,2,0),
            ConvNeXt_block(192, 2, act=False),
            ConvNeXt_block(192, 4, act=False),
            DownSampleConvN(256,2,2,0),
            ConvNeXt_block(256, 2, act=False),
            ConvNeXt_block(256, 4, act=False),
            kl.AveragePooling2D(pool_size=(7, 7)),
            Flatten(),
            Dense(hp.num_classes)
              ## Add layers here separated by commas.
        ]

    def call(self, x):
        """ Passes input image through the network. """

        for layer in self.architecture:
            x = layer(x)

        return x

    @staticmethod
    def loss_fn(labels, predictions):
        """ Loss function for the model. """

        # TODO: Select a loss function for your network (see the documentation
        #       for tf.keras.losses)

        return tf.keras.losses.sparse_categorical_crossentropy(
            labels, predictions, from_logits=False)


class VGGModel(tf.keras.Model):
    def __init__(self):
        super(VGGModel, self).__init__()

        # TODO: Select an optimizer for your network (see the documentation
        #       for tf.keras.optimizers)

        self.optimizer = tf.keras.optimizers.RMSprop(
            learning_rate=hp.learning_rate,
            momentum=hp.momentum)

        self.vgg16 = [
            # Block 1
            Conv2D(64, 3, 1, padding="same",
                   activation="relu", name="block1_conv1"),
            Conv2D(64, 3, 1, padding="same",
                   activation="relu", name="block1_conv2"),
            MaxPool2D(2, name="block1_pool"),
            # Block 2
            Conv2D(128, 3, 1, padding="same",
                   activation="relu", name="block2_conv1"),
            Conv2D(128, 3, 1, padding="same",
                   activation="relu", name="block2_conv2"),
            MaxPool2D(2, name="block2_pool"),
            # Block 3
            Conv2D(256, 3, 1, padding="same",
                   activation="relu", name="block3_conv1"),
            Conv2D(256, 3, 1, padding="same",
                   activation="relu", name="block3_conv2"),
            Conv2D(256, 3, 1, padding="same",
                   activation="relu", name="block3_conv3"),
            MaxPool2D(2, name="block3_pool"),
            # Block 4
            Conv2D(512, 3, 1, padding="same",
                   activation="relu", name="block4_conv1"),
            Conv2D(512, 3, 1, padding="same",
                   activation="relu", name="block4_conv2"),
            Conv2D(512, 3, 1, padding="same",
                   activation="relu", name="block4_conv3"),
            MaxPool2D(2, name="block4_pool"),
            # Block 5
            Conv2D(512, 3, 1, padding="same",
                   activation="relu", name="block5_conv1"),
            Conv2D(512, 3, 1, padding="same",
                   activation="relu", name="block5_conv2"),
            Conv2D(512, 3, 1, padding="same",
                   activation="relu", name="block5_conv3"),
            MaxPool2D(2, name="block5_pool")
        ]

        # TODO: Make all layers in self.vgg16 non-trainable. This will freeze the
        #       pretrained VGG16 weights into place so that only the classificaiton
        #       head is trained.

        for layer in self.vgg16:
            layer.trainable = False

        # TODO: Write a classification head for our 15-scene classification task.

        self.head = [
            # Block 6
            Flatten(name="block5_flatten"),
            Dense(512, activation="relu"),
            # Block 7
            Dense(512, activation="relu"),
            # Block 8
            Dense(hp.num_classes, activation="softmax"),
        ]

        # Don't change the below:
        self.vgg16 = tf.keras.Sequential(self.vgg16, name="vgg_base")
        self.head = tf.keras.Sequential(self.head, name="vgg_head")

    def call(self, x):
        """ Passes the image through the network. """

        x = self.vgg16(x)
        x = self.head(x)

        return x

    @staticmethod
    def loss_fn(labels, predictions):
        """ Loss function for model. """

        # TODO: Select a loss function for your network (see the documentation
        #       for tf.keras.losses)

        return tf.keras.losses.sparse_categorical_crossentropy(
            labels, predictions, from_logits=False)
